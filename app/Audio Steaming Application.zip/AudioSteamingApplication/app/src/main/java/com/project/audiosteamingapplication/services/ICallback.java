package com.project.audiosteamingapplication.services;

import android.graphics.Bitmap;

public interface ICallback {

    void done(Bitmap bitmap);
}